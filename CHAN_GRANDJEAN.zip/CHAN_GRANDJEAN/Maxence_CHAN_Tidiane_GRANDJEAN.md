# 5. Mise en pratique (Examen) #

## 5.1. Préparation de la vm (MrJob, Python ...) ##
### En partant du fichier ml-25m/tags.csv du TP Hadoop, il vous est donc demandé de répondre à ces questions : ###
Combien de tags chaque film possède-t-il ? 
Combien de tags chaque utilisateur a-t-il ajoutés ?
### 5.1.1 Téléchargement et décompréssion ###

Dans un premier temps nous devons telecharger le fichier puis le décomprésser

Pour télécharger le fichier :
```bash 
wget https://files.grouplens.org/datasets/movielens/ml-25m.zip
```
![alt text](image.png)

Décompréssion :
```bash 
unzip ml-25m.zip
```
![alt text](image-1.png)

### 5.1.2 Installation de la dernière version de la SandBox HDP ###

Instalation de la dernière mise a jour de la SandBox HDP :
```bash 
sudo su root
yum-config-manager --save --setopt=HDP-SOLR-2.6-100.skip_if_unavailable=true
```
![alt text](image-3.png)
```bash 
yum install https://repo.ius.io/ius-release-el7.rpm https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
```
![alt text](image-4.png)

### 5.1.3 Installation de python-pip ###

Instalation de python-pip :
```bash 
curl https://bootstrap.pypa.io/pip/2.7/get-pip.py -o get-pip.py
```
![alt text](image-5.png)
```bash 
sudo python get-pip.py 
```
![alt text](image-6.png)

Vérification de l'installation de python :
```bash 
pip --version
```
![alt text](image-7.png)

### 5.1.4 Instalation de MrJob ###
```bash 
pip install pathlib
```
![alt text](image-8.png)

```bash 
pip install mrjob==0.7.4
```
![alt text](image-9.png)

```bash 
pip install PyYAML==5.4.1
```
![alt text](image-10.png)

### 5.1.5 Instalation de NANO ###

La commande suivante ne marche pas :
```bash 
yum install nano
```

Nous devons installer NANO localement et manuellement : 
```bash 
cd /tmp
```
```bash 
wget http://vault.centos.org/7.9.2009/os/x86_64/Packages/nano-2.3.1-10.el7.x86_64.rpm
```
![alt text](image-11.png)

```bash 
rpm -ivh nano-2.3.1-10.el7.x86_64.rpm
```
![alt text](image-12.png)

NANO est correctement installé, nous retournons donc maintenant vers l'utilisateur maria_dev avec la commande "su".

```bash 
cd -
```
![alt text](image-13.png)

Puis...
```bash 
su maria_dev
```
![alt text](image-14.png)

Enfin juste a se login a nouveau.

## 5.2. Map-Reduce ##
### 5.2.1 Récuperation du code et des données ###
```bash 
wget https://github.com/juba-agoun/iut-hadoop/raw/main/filmEvaluation.py
```
![alt text](image-15.png)
```bash 
wget https://github.com/juba-agoun/iut-hadoop/raw/main/evaluation.data
```
![alt text](image-16.png)

# 6. Mise en pratique (Examen) #
En partant du fichier ml-25m/tags.csv du TP Hadoop, il vous est donc demandé de répondre à ces questions :

Combien de tags chaque film possède-t-il ?
Combien de tags chaque utilisateur a-t-il ajoutés ?

## 6.1. Création des dossiers ##
Dans un premier temps nous devons créer un dossier et y transférer le fichier genome-tags.csv.

Création du dossier pour stocker notre jeu de données dans HDFS :
```bash 
hdfs dfs -mkdir dossier
```
Migration du fichier tags.csv dans HDFS :
```bash 
hdfs dfs -moveFromLocal ml-25m/tags.csv dossier
```

## 6.2. Combien de tags chaque film possède-t-il ? ##
Pour commencer nous avons créer notre code Map-Reduce sur python pour compter le nombre de tags pour chaque film  
```python 
from mrjob.job import MRJob
from mrjob.step import MRStep

class TagCounts(MRJob):
    def steps(self):
        return [
            MRStep(mapper=self.mapper_get_tags,
                   reducer=self.reducer_count_tags)
        ]

    def mapper_get_tags(self, _, line):
        try:
            userID, movieID, tag, timestamp = line.split(',')
            yield movieID, 1
        except Exception:
            pass

    def reducer_count_tags(self, movieID, counts):
        yield movieID, sum(counts)

if __name__ == '__main__':
    TagCounts.run()
```
Puis nous avons transferer le code sur GitHub afin d'y acceder via Hadoop. Voici le code pour importer le fichier python Map-Reduce :
```bash 
wget https://raw.githubusercontent.com/MaxenceCHAN07/BigData/main/map_reduce.py
```

Voici l'execution sur notre fichier tags.csv :
```bash 

```
Nous avons décider de stocker les resultats pour les vérifier. Une fois le code executé et finis nous avons récuperer le fichier en passant par Ambari. 

Démarche effectué screen :
1) Aller dans les petits carrés a côté de maria_dev et sélectionner Files_View :

![alt text](image-19.png)

2) Se rendre ensuite dans le répertoire où le fichier a été stocké :

![alt text](image-20.png)

3) Sélectionner ensuite le fichier part-0000 qui contient les résultats de notre map reduce :

![alt text](image-21.png)



Voici le lien vers le GitHub afin de visualiser les résulats : https://github.com/MaxenceCHAN07/BigData/blob/main/Question%201

## 6.3. Combien de tags chaque utilisateur a-t-il ajoutés ? ##
Pour commencer nous avons créer notre code Map-Reduce sur python pour compter le nombre de tags pour chaque utilisateur
```python 
from mrjob.job import MRJob
from mrjob.step import MRStep

class TagCounts(MRJob):
    def steps(self):
        return [
            MRStep(mapper=self.mapper_get_tags,
                   reducer=self.reducer_count_tags)
        ]

    def mapper_get_tags(self, _, line):
        try:
            userID, movieID, tag, timestamp = line.split(',')
            yield userID, 1  # Nous émettons l'userID et 1 pour chaque tag ajouté par cet utilisateur
        except Exception:
            pass

    def reducer_count_tags(self, userID, counts):
        yield userID, sum(counts)  # Nous additionnons tous les 1 pour obtenir le nombre de tags par utilisateur

if __name__ == '__main__':
    TagCounts.run()
```

Puis nous avons transferer le code sur GitHub afin d'y acceder via Hadoop. Voici le code pour importer le fichier python Map-Reduce :
```bash 
wget https://raw.githubusercontent.com/MaxenceCHAN07/BigData/main/map_reduce2.py
```

Voici l'execution sur notre fichier tags.csv :
```bash 
python map_reduce2.py -r hadoop --hadoop-streaming-jar /usr/hdp/current/hadoop-mapreduce-client/hadoop-streaming.jar hdfs:///user/maria_dev/dossier/tags.csv -o resultat2.csv
```
Nous avons décider de stocker les resultats pour les vérifier. Une fois le code executé et finis nous avons récuperer le fichier en passant par Ambari. 

Démarche effectué screen :
1) Aller dans les petits carrés a côté de maria_dev et sélectionner Files_View :

![alt text](image-19.png)

2) Se rendre ensuite dans le répertoire où le fichier a été stocké :

![alt text](image-20.png)

3) Sélectionner ensuite le fichier part-0000 qui contient les résultats de notre map reduce :

![alt text](image-21.png)


Voici le lien vers le GitHub afin de visualiser les résulats : https://github.com/MaxenceCHAN07/BigData/blob/main/Question%202

## 6.4. Combien de blocs le fichier occupe-t-il dans HDFS dans chacune des configurations ? ##

Avec la taille du bloc par défaut (128 Mo)
```bash 
hdfs fsck /user/maria_dev/dossier/tags.csv -files -blocks
```
![alt text](image-22.png)
Nous observons que le fichier tags.csv occupe seulement 1 bloc. Avec une taille total de 38810332 B. Ce qui corresponf a 38,8 Mo. Cette mesure est inférieur à 128 Mo c'est pour cela que le fichier occupe seulement 1 bloc.

Avec la taille du bloc = 64 Mo
Il faut en premier importer nos données avec un bloc = 64 Mo.
Nous décompressons a nouveau un fichier tags.csv :
```bash 
unzip ml-25m
```

Puis, nous créons un répertoire où on va définir la taille des blocs pour notre fichier :
```bash 
hdfs dfs -mkdir test
```

Ensuite nous importons le fichier avce des blocs = 64 Mo :
```bash 
hdfs dfs -Ddfs.blocksize=67108864 -put ml-25m/tags.csv test/tags.csv
```

Enfin, nous pouvons regarder la taille du fichier : 
```bash 
hdfs fsck /user/maria_dev/test/tags.csv -files -blocks
```
![alt text](image-24.png)
Nous observons également que le fichier tags.csv occupe seulement 1 bloc. Avec une taille total de 38810332 B. Ce qui corresponf a 38,8 Mo. Cette mesure est inférieur à 128 Mo c'est pour cela que le fichier occupe seulement 1 bloc.

## 6.5. Combien de fois chaque tag a-t-il été utilisé pour taguer un film ? ##
Pour commencer nous avons créer notre code Map-Reduce sur python pour compter combien de fois chaque tag a été utiliser pour  taguer un film.

```python 
from mrjob.job import MRJob
from mrjob.step import MRStep

class TagCounts(MRJob):
    def steps(self):
        return [
            MRStep(mapper=self.mapper_get_tags,
                   reducer=self.reducer_count_tags)
        ]

    def mapper_get_tags(self, _, line):
        try:
            userID, movieID, tag, timestamp = line.split(',')
            yield tag, 1
        except Exception:
            pass

    def reducer_count_tags(self, tag, counts):
        yield tag, sum(counts)

if __name__ == '__main__':
    TagCounts.run()
```

Puis nous avons transferer le code sur GitHub afin d'y acceder via Hadoop. Voici le code pour importer le fichier python Map-Reduce :
```bash 
wget https://raw.githubusercontent.com/MaxenceCHAN07/BigData/main/map_reduce4.py
```

Voici l'execution sur notre fichier tags.csv :
```bash 
python map_reduce4.py -r hadoop --hadoop-streaming-jar /usr/hdp/current/hadoop-mapreduce-client/hadoop-streaming.jar hdfs:///user/maria_dev/dossier/tags.csv -o resultat4.csv
```
Nous avons décider de stocker les resultats pour les vérifier. Une fois le code executé et finis nous avons récuperer le fichier en passant par Ambari. 

Démarche effectué screen :
1) Aller dans les petits carrés a côté de maria_dev et sélectionner Files_View :

![alt text](image-19.png)

2) Se rendre ensuite dans le répertoire où le fichier a été stocké :

![alt text](image-20.png)

3) Sélectionner ensuite le fichier part-0000 qui contient les résultats de notre map reduce :

![alt text](image-21.png)


Voici le lien vers le GitHub afin de visualiser les résulats : https://github.com/MaxenceCHAN07/BigData/blob/main/Question%204

## 6.6. Pour chaque film, combien de tags le même utilisateur a-t-il introduits (Question Bonus) ? ##
Pour commencer nous avons créer notre code Map-Reduce sur python pour compter pour chaque film, combien de tags le même utilisateur a-t-il introduits.

```python 
from mrjob.job import MRJob
from mrjob.step import MRStep

class TagsPerUserPerFilm(MRJob):
    
    def steps(self):
        return [
            MRStep(mapper=self.mapper_get_user_film_tags,
                   reducer=self.reducer_count_tags)
        ]
    
    def mapper_get_user_film_tags(self, _, line):
        try:
            userID, movieID, tag, timestamp = line.strip().split(',')
            key = "{}_{}".format(userID, movieID)  # Combine userID and movieID
            yield key, 1  # For each tag, we yield 1
        except ValueError:
            pass  # Ignore malformed lines

    def reducer_count_tags(self, user_film, counts):
        total_tags = sum(counts)  # Count the total number of tags per user per film
        yield user_film, total_tags

if __name__ == '__main__':
    TagsPerUserPerFilm.run()
```

Puis nous avons transferer le code sur GitHub afin d'y acceder via Hadoop. Voici le code pour importer le fichier python Map-Reduce :
```bash 
wget https://raw.githubusercontent.com/MaxenceCHAN07/BigData/main/map_reduce_bonus.py
```

Voici l'execution sur notre fichier tags.csv :
```bash 
python map_reduce_bonus.py -r hadoop --hadoop-streaming-jar /usr/hdp/current/hadoop-mapreduce-client/hadoop-streaming.jar hdfs:///user/maria_dev/dossier/tags.csv -o resultat_bonus.csv
```
Nous avons décider de stocker les resultats pour les vérifier. Une fois le code executé et finis nous avons récuperer le fichier en passant par Ambari. 

Démarche effectué screen :
1) Aller dans les petits carrés a côté de maria_dev et sélectionner Files_View :

![alt text](image-19.png)

2) Se rendre ensuite dans le répertoire où le fichier a été stocké :

![alt text](image-20.png)

3) Sélectionner ensuite le fichier part-0000 qui contient les résultats de notre map reduce :

![alt text](image-21.png)

Voici le lien vers le GitHub afin de visualiser les résulats : https://github.com/MaxenceCHAN07/BigData/blob/main/Question%20bonus ou https://raw.githubusercontent.com/MaxenceCHAN07/BigData/refs/heads/main/Question%20bonus
